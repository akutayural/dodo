from dodo.commands import run_dodo_shell



def main():
    run_dodo_shell()


if __name__ == "__main__":
    main()